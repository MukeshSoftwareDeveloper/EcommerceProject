from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from .models import UserProfile
from django.contrib.auth import authenticate, login, logout

def signup(request):
	if request.method == "POST":
		un = request.POST['uname']
		pwd = request.POST['pwd']
		fn = request.POST['fname']
		ln = request.POST['lname']
		email = request.POST['email']
		mob = request.POST['mob']
		role = request.POST['role']

		u = User(username=un,password=make_password(pwd),first_name=fn,last_name=ln,email=email)
		u.save()

		up = UserProfile(user=u, mobile=mob,role=role)
		up.save()
		return redirect('/signup/')

	return render(request, "signup.html")

def login_call(request):
	if request.method == "POST":
		un = request.POST['uname']
		pwd = request.POST['pwd']

		user = authenticate(username=un, password=pwd)

		if user:
			login(request, user)
			uObj = UserProfile.objects.get(user__username=request.user)
			
			if uObj.role == "seller":
				return redirect('/seller/home/')
			elif uObj.role == "buyer":
				return redirect('/buyer/home/')
			
			return render(request, 'index.html')
		else:
			return HttpResponse("<h1>Invalid Username or Password!</h1>")

	return render(request, "login.html")

def logout_call(request):
	logout(request)
	return redirect('/login/')