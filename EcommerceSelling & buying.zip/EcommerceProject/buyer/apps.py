from django.apps import AppConfig


class BuyerConfig(AppConfig):
    name = 'buyer'
