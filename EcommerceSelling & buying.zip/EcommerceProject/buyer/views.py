from django.shortcuts import render, redirect
from seller.models import Product, Category
from django.contrib import messages
from EcommerceProject.models import UserProfile
from .models import Cart

# Create your views here.
def home(request):
	uObj = UserProfile.objects.get(user__username=request.user)
	cnt = Cart.objects.filter(user_id=uObj.id).count()

	cObjs = Category.objects.all()
	pObjs = Product.objects.all()
	return render(request, "WelcomeBuyer.html", {'cObjs':cObjs, 'pObjs':pObjs, 'count':cnt})

def add_cart(request, id):
	pObj = Product.objects.get(id=id)
	uObj = UserProfile.objects.get(user__username=request.user)

	try:
		c = Cart(product=pObj, user=uObj)
		c.save()
		messages.success(request, "Item added successfully!")
		return redirect('/buyer/home/')
	except:
		messages.error(request, "Already Exist!")
		return redirect('/buyer/home/')

def cartdetails(request):
	uObj = UserProfile.objects.get(user__username=request.user)
	cnt = Cart.objects.filter(user_id=uObj.id).count()
	cartObjs = Cart.objects.filter(user_id=uObj.id)
	#print(cartObjs)
	items = []

	for i in cartObjs:
		items.append(Product.objects.get(id=i.product_id))

	#print(items)
	return render(request, "CartDetails.html", {'pObjs':items, 'count':cnt})

def delcart(request, id):
	uObj = UserProfile.objects.get(user__username=request.user)
	pObj = Product.objects.get(id=id)

	c = Cart.objects.get(user=uObj, product=pObj)
	c.delete()
	return redirect('/buyer/cartdetails/')

def cartcalculate(request):
	pQty = request.POST.getlist('p_qty')
	pid = request.POST.getlist('pid')
	price = request.POST.getlist('price')

	uObj = UserProfile.objects.get(user__username=request.user)

	#Total, Update (QTY), Cart Clear, Order
	amount = 0
	for i in range(len(pQty)):
		amount = amount + (int(pQty[i])*float(price[i]))

		pObj = Product.objects.filter(id=pid[i])
		updatedQty = pObj[0].qty - int(pQty[i])
		pObj.update(qty=updatedQty)

	c = Cart.objects.filter(user_id=uObj.id)
	c.delete()

	#createOrder()

	return redirect('/buyer/checkout/')


		
def checkout(request):
	return render(request, "checkout.html")

def catwisefilter(request, id):
	pObjs = Product.objects.filter(category_id = id)
	#pass