from django.urls import path
from . import views

app_name = 'buyer'

urlpatterns = [
	path('home/', views.home),
	path('add_cart/<int:id>/', views.add_cart, name='cart'),
	path('cartdetails/', views.cartdetails),
	path('delcart/<int:id>/', views.delcart, name="delcart"),
	path('cartcalculate/', views.cartcalculate),
	path('checkout/', views.checkout),
	path('catwisefilter/<int:id>/', views.catwisefilter, name="catFilter")
]